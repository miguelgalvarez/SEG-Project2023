package com.example.myapplication.loginpage;

public interface LoginCallBack {
    void onLoginResult(boolean success);
}
